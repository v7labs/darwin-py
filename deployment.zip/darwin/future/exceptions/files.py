from darwin.future.exceptions.base import DarwinException


class UnrecognizableFileEncoding(DarwinException):
    pass
