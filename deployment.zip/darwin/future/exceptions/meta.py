from darwin.future.exceptions.base import DarwinException


class MetaException(DarwinException):
    pass
