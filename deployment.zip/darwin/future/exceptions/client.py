from darwin.future.exceptions.base import DarwinException


class NotFound(DarwinException):
    pass


class Unauthorized(DarwinException):
    pass
