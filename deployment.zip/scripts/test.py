import os
from pathlib import Path

from darwin.datatypes import PathLike
from darwin.future.core.items.get import get_item_ids_stage
from darwin.future.core.items.move_items import move_items_to_stage
from darwin.future.data_objects.team_member_role import TeamMemberRole
from darwin.future.meta.client import MetaClient
from darwin.future.meta.queries.team_member import TeamMemberQuery

client = MetaClient.local()
dataset = client.team.datasets.where(name="nathanp_dev")[0]
item_ids = dataset.item_ids(client.team.slug)
workflow = client.workflows.where(dataset_name="nathanp_dev")[0]

files = [Path("/Users/nathanperkins/Development/testacular.jpeg")]
workflow.upload_files(files, verbose=True)
stages = workflow.stages.where(name="annotation").collect()
ds_stage = workflow.stages[0]
annotate_stage = workflow.stages[1]
items_on_annotation = annotate_stage.item_ids
stage[0].move_attached_files_to_stage(stage[1])
stage[0].items
print(items_on_annotation)
