.. darwin-py documentation master file, created by
   sphinx-quickstart on Thu Aug  5 15:43:37 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. toctree::
   :hidden:
   :maxdepth: 3

   Packages <modules>
   README <README>

.. include:: README.rst